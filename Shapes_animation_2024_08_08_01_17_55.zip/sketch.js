let ball;
let angle = 0;

function setup() {
  createCanvas(400, 400);
  ball = new Ball();
}

function draw() {
  background(220);

  // Update and display the ball
  ball.move();
  ball.display();

  // Update and display the rotating rectangle
  push();
  translate(width / 2, height / 2);
  rotate(angle);
  fill(100, 150, 250);
  rectMode(CENTER);
  rect(0, 0, 100, 50);
  pop();

  // Update the rotation angle
  angle += 0.05;
}

class Ball {
  constructor() {
    this.x = width / 2;
    this.y = height / 2;
    this.diameter = 50;
    this.xSpeed = 3;
    this.ySpeed = 2;
  }

  move() {
    this.x += this.xSpeed;
    this.y += this.ySpeed;

    // Bounce off the edges
    if (this.x > width - this.diameter / 2 || this.x < this.diameter / 2) {
      this.xSpeed *= -1;
    }
    if (this.y > height - this.diameter / 2 || this.y < this.diameter / 2) {
      this.ySpeed *= -1;
    }
  }

  display() {
    fill(250, 100, 100);
    noStroke();
    ellipse(this.x, this.y, this.diameter);
  }
}